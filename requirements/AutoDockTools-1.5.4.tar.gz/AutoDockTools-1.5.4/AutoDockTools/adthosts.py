hostMacros = {
    'localhost': { 'host' : 'localhost',
		   'autogrid' : 'autogrid4',
                   'autodock' : 'autodock4',
                   'queuetype' : 'int',
                   'userSpecific' : 0 },

    }

