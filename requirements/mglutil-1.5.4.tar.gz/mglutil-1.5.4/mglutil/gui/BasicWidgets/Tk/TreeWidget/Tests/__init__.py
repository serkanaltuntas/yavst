pauseLength = 0.001
