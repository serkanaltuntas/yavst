#############################################################################
#
# Author: Michel F. SANNER
#
# Copyright: M. Sanner TSRI 2000
#
#############################################################################

#
# $Header: /opt/cvs/python/packages/share1.5/MolKit/moleculeWriter.py,v 1.1.1.1 2001/04/03 19:47:52 gillet Exp $
#
# $Id: moleculeWriter.py,v 1.1.1.1 2001/04/03 19:47:52 gillet Exp $
#

class MoleculeWriter:

    pass


